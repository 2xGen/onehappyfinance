
import React from 'react';
import { NavLink } from 'react-router-dom';
import Logo from '@/components/Logo';

const Footer = () => {
  return (
    <footer id="contact" className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-8">
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
               <NavLink to="/" className="mb-4">
                 <Logo color="#FFFFFF" />
               </NavLink>
              <p className="text-gray-300 leading-relaxed max-w-xs mx-auto md:mx-0">
                Your trusted source for financial clarity in Aruba.
              </p>
            </div>

            <div className="text-center md:text-right">
                <p className="text-gray-400 text-sm max-w-sm">
                    Information only – we are not a financial institution or mortgage provider. All content is for informational purposes and does not constitute financial advice.
                </p>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center">
            <p className="text-gray-400">
              © {new Date().getFullYear()} OneHappyFinance.com. All Rights Reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
