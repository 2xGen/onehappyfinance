
import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { MapPin, Eye, Ban, Gift, Users, BarChart } from 'lucide-react';

const WhyChooseUs = () => {
  const [ref, isInView] = useInView({ threshold: 0.2 });

  const reasons = [
    {
      icon: MapPin,
      text: "100% focused on Aruba and the Caribbean"
    },
    {
      icon: Eye,
      text: "Transparent, easy-to-read financial information"
    },
    {
      icon: Ban,
      text: "No sales pressure — just clarity"
    },
    {
      icon: Gift,
      text: "Free resources, guides, and local insights"
    },
    {
      icon: Users,
      text: "Helping both residents and foreigners navigate the system"
    },
    {
      icon: BarChart,
      text: "Up-to-date with local market changes"
    }
  ];

  return (
    <section ref={ref} className="py-20 md:py-28 bg-primary">
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-[28px] font-bold mb-6 text-white">Why Choose Us?</h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12 max-w-6xl mx-auto">
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-start gap-4"
            >
              <div className="bg-white/20 p-3 rounded-lg flex-shrink-0">
                  <reason.icon className="w-6 h-6 text-white" />
                </div>
              <p className="text-lg text-white/90 leading-relaxed">{reason.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
