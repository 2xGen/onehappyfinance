
import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from '@/hooks/useInView';
import { ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const FeaturedGuides = () => {
  const [ref, isInView] = useInView({ threshold: 0.1 });
  const { toast } = useToast();

  const guides = [
    {
      title: "Buying a House in Aruba as a Foreigner – What You Should Know",
      excerpt: "A complete guide to property ownership requirements, legal processes, and financial considerations.",
      category: "Property",
      imgAlt: "Keys to a new home on a table with Aruban scenery in the background"
    },
    {
      title: "Mortgage Rates in Aruba: What's Changing in 2026?",
      excerpt: "Our analysis on interest rates, lending policies, and what they mean for your home buying journey.",
      category: "Mortgages",
      imgAlt: "A calculator and pen on top of mortgage application documents"
    },
    {
      title: "The Complete Guide to Home Insurance in Aruba",
      excerpt: "Everything you need to know about protecting your property investment in Aruba's climate.",
      category: "Insurance",
      imgAlt: "A family standing in front of their beautiful Aruban home"
    },
  ];

  const handleGuideClick = () => {
    toast({
      title: "🚧 Coming Soon!",
      description: "Our detailed guides are being published. Check back soon for expert insights!",
      duration: 4000,
    });
  };

  return (
    <section id="guides" ref={ref} className="py-20 md:py-28 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-[28px] font-bold mb-4">Featured Guides</h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Our latest articles to help you navigate Aruba's financial landscape.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {guides.map((guide, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden group cursor-pointer transition-transform duration-300 hover:-translate-y-2"
              onClick={handleGuideClick}
            >
              <div className="h-48 overflow-hidden">
                <img class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={guide.imgAlt} src="https://images.unsplash.com/photo-1599213153841-a1d614be79de" />
              </div>
              <div className="p-6">
                <span className="inline-block px-3 py-1 bg-secondary/10 text-secondary text-sm font-semibold rounded-full mb-3">
                  {guide.category}
                </span>
                <h3 className="font-heading text-lg font-semibold mb-3 text-foreground leading-tight">
                  {guide.title}
                </h3>
                <p className="text-foreground/80 mb-4 leading-relaxed text-sm">
                  {guide.excerpt}
                </p>
                <div 
                  className="text-primary hover:text-primary-hover font-semibold group-hover:text-primary-hover flex items-center transition-colors"
                >
                  Read More
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedGuides;
