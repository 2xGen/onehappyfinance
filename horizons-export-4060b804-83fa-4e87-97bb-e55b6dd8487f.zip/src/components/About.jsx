
import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const About = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const variants = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section ref={ref} className="py-20 md:py-28 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
          
           {/* Text Content - Order 1 on mobile */}
           <motion.div
            className="order-1 md:order-2"
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            variants={variants}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <h2 className="font-heading text-3xl md:text-4xl font-bold mb-6 text-center md:text-left">
              Built for Aruba’s Financial Reality
            </h2>
            <div className="space-y-4 text-lg text-foreground/80 text-center md:text-left">
              <p>
                Aruba’s economy runs on strong families, small businesses, and home ownership. But finding the right financial information isn’t always easy — banks, brokers, and insurers often speak in complicated terms.
              </p>
              <p>
                That’s where OneHappyFinance comes in. We’re here to make financial topics <span className="text-primary font-semibold">simple, transparent, and local.</span>
              </p>
              <p>
                From understanding mortgage interest rates to comparing insurance options, our goal is to give you clarity before you make important financial decisions.
              </p>
            </div>
          </motion.div>

          {/* Image Content - Order 2 on mobile */}
          <motion.div
            className="relative order-2 md:order-1"
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            variants={{
              visible: { opacity: 1, scale: 1 },
              hidden: { opacity: 0, scale: 0.9 }
            }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
             <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl -rotate-3 md:-rotate-3">
              <img 
                src="https://soaacpusdhyxwucjhhpy.supabase.co/storage/v1/object/public/One%20Happy%20Finance/one%20happy%20finance.png"
                alt="Smiling professional woman in an office setting" 
                className="w-full h-full object-cover object-center"
              />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default About;
