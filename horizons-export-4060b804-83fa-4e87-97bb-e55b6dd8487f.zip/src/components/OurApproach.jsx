
import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const OurApproach = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const variants = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section ref={ref} className="py-20 md:py-28 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
          
          {/* Text Content - Order 1 on mobile */}
          <motion.div
            className="order-1"
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            variants={variants}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <h2 className="font-heading text-3xl md:text-4xl font-bold mb-6 text-center md:text-left">
              Your Clear Path to Financial Confidence
            </h2>
            <div className="space-y-4 text-lg text-foreground/80 text-center md:text-left">
              <p>
                At OneHappyFinance, we believe everyone deserves clear, unbiased financial guidance. Our approach is built on simplicity, transparency, and a deep understanding of Aruba's unique financial landscape.
              </p>
              <p>
                We cut through the jargon to provide you with actionable insights, easy-to-understand guides, and honest comparisons. Your peace of mind is our priority, ensuring you make choices that truly benefit your future on the island.
              </p>
              <p>
                Whether you're a long-time resident or new to Aruba, trust us to be your partner in navigating mortgages, insurance, pensions, and more.
              </p>
            </div>
          </motion.div>

          {/* Image Content - Order 2 on mobile */}
          <motion.div
            className="relative order-2"
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            variants={{
              visible: { opacity: 1, scale: 1 },
              hidden: { opacity: 0, scale: 0.9 }
            }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl rotate-3 md:rotate-3">
              <img 
                src="https://soaacpusdhyxwucjhhpy.supabase.co/storage/v1/object/public/One%20Happy%20Finance/onehappyfinance.png"
                alt="Professional financial advisor smiling" 
                className="w-full h-full object-cover object-center"
              />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default OurApproach;
