
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const navigate = useNavigate();

  return (
    <section className="relative bg-gradient-to-br from-blue-50 to-white -mt-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 items-center gap-8 md:gap-12 min-h-screen pt-28 md:pt-20">
          
          {/* Text Content (Order 1 on mobile and desktop) */}
          <div className="pt-8 md:pt-0 text-center md:text-left order-1">
            <motion.h1 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="font-heading text-4xl md:text-[42px] font-bold mb-6 leading-tight text-foreground"
            >
              Your Trusted Guide to Mortgages, Insurance, and Finance in Aruba
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="text-lg md:text-xl mb-10 text-foreground/80"
            >
              At OneHappyFinance, we simplify everything — from mortgage options to insurance and pension planning — so you can make confident, informed decisions.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="flex justify-center md:justify-start"
            >
              <Button 
                size="lg" 
                onClick={() => navigate('/guides')}
                className="shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40"
              >
                Explore Our Guides
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          </div>

          {/* Image Content (Order 2 on mobile and desktop) */}
          <motion.div 
            className="relative h-80 md:h-auto order-2"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl rotate-3 md:rotate-3 translate-x-2 md:translate-x-4">
               <img 
                src="https://soaacpusdhyxwucjhhpy.supabase.co/storage/v1/object/public/One%20Happy%20Finance/One%20Happy%20Finance%20Aruba.png" 
                alt="A luxurious modern home in Aruba with a pool overlooking the ocean at sunset" 
                className="w-full h-full object-cover" 
              />
            </div>
          </motion.div>

        </div>
      </div>
       <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default Hero;
